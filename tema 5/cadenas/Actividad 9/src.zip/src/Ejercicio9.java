/*
Escribe un programa que sea capaz de contar el número de palabras diferentes que hay en un texto que se le pasa por argumento, 
sin tener en cuenta si están escritas en mayúsculas o minúsculas.

Ayuda:
Con la instrucción siguiente, eliminamos todas los signos contiguos a una palabra como por ejemplo la coma. Ej. "El libro, ..."
palabra = palabra.replaceAll("[^a-z0-9áéíóúüñ]", "");
*/

import java.util.Scanner;

public class Ejercicio9 {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("Dame las palabras que quieras que cuente = ");
        String cadena = sc.nextLine();
        int contarPalabra = contador(cadena);
        System.out.println("Tiene un total de --> "+contarPalabra+" palabras");
        sc.close();
    }

    private static int contador(String cadena) {
        int contador = 1;
        for (int i = 0;i<cadena.length();i++) {
            char c = cadena.charAt(i);
            if (c == ' ' || c == ',') contador++;
        }
        return contador;
    }
}
