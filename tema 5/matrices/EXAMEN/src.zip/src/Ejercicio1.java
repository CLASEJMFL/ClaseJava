import java.util.Arrays;
import java.util.Collections;

public class Ejercicio1 {
    public static void main(String[] args) throws Exception {
        int [] numeros = {1,8,2,7,3,6,4,5};
        int max = otenerMax(numeros);
        int min = obtenerMin(numeros);
        int[] ordenarAsc = ordenarAscendente(numeros);
        //int[] ordenarDsc = ordenarDescendente(numeros);
        // Sacamos por pantalla
        System.out.print("\nNumero mas grande = "+max );
        System.out.print("\nNumero mas pequeño = "+min );
        System.out.print("\nOrden ascendente = ");
        System.out.print(Arrays.toString(ordenarAsc));
        //System.out.print("\nOrden descendenete = ");
        //System.out.print(Arrays.toString(ordenarDsc));
        System.out.println("");


    }

    //private static int[] ordenarDescendente(int[] numeros) {
        //Arrays.sort(Collections.reverseOrder(numeros);
    //    return numeros;
    //}


    // Ordenamos y sacamos el array ya en orden ascendente
    private static int[] ordenarAscendente(int[] numeros) {
        Arrays.sort(numeros);
        return numeros;
    }
    // Hacemos lo mismo que en el numero mas alto pero con el 0 ya que es el mas pequeño
    private static int obtenerMin(int[] numeros) {Arrays.sort(numeros);
        Arrays.sort(numeros);
        int min = numeros[0];
        return min;
    }
    // Primero ordenamos y despues cogemos el numero mas alto que seria la longitud que tiene el array -1
    private static int otenerMax(int[] numeros) {
        Arrays.sort(numeros);
        int max = numeros[numeros.length-1];
        return max;
    }


}
